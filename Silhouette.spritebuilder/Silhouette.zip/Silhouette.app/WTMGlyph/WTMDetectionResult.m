//
//  WTMDetectionResult.m
//  WTMGlyphDemo
//
//  Created by Ben Gotow on 1/27/13.
//  Copyright (c) 2013 torin.nguyen@2359media.com. All rights reserved.
//

#import "WTMDetectionResult.h"
#import "WTMGlyph.h"

@implementation WTMDetectionResult

@end
